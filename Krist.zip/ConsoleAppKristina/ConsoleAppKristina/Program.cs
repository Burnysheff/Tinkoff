﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;

namespace ConsoleAppKristina
{
    public class Program
    {
        public static void MaxSpeed(params Animal[] mass)
        {
            Animal[] res = new Animal[25];
            int kolich = 0;
            uint summ = 0;
            for (int i = 0; i < Animal.count; i++)
            {
                if (mass[i] is Artiodactyl)
                {
                    summ = summ + ((Artiodactyl)mass[i]).MaxSpeed;
                    kolich++;
                }
            }
            if (kolich == 0)
            {
                Console.WriteLine("\nПарнокопытные еще не созданы!\n");
                return;
            }
            Console.WriteLine("\nИх средняя скорость: " + (int)summ / kolich + "\n");
        }
        public static void Wingspan(params Animal[] mass)
        {
            Animal[] res = new Animal[25];
            int kolich = 0;
            for (int i = 0; i < Animal.count; i++)
            {
                Bird x = mass[i] as Bird;
                if (x != null)
                {
                    if (x.Wingspan > 70)
                    {
                        res[kolich] = x;
                        kolich++;
                    }
                }
            }
            if (kolich == 0)
            {
                Console.WriteLine("\nТаких элементов в массиве нет!\n");
                return;
            }
            Console.WriteLine("\nРезультат: ");
            for (int i = 0; i < kolich; i++)
            {
                res[i].Show();
            }
            Console.WriteLine("\nВсего таких элементов обнаружено: " + kolich + "\n");
        }
        public static void PoiskBolota(params Animal[] mass)
        {
            Console.WriteLine("\nВсе вон с моего болота!!!");
            Animal[] res = new Animal[25];
            int kolich = 0;
            for (int i = 0; i < Animal.count; i++)
            {
                if (mass[i].Sreda == "swamp")
                {
                    res[kolich] = mass[i];
                    kolich++;
                }
            }
            if (kolich == 0)
            {
                Console.WriteLine("\nТам никого не осталось...(или не было)\n");
                return;
            }
            Console.WriteLine("\nРезультат: ");
            for (int i = 0; i < kolich; i++)
            {
                res[i].Show();
            }
            Console.WriteLine("\nВсего на болоте живет " + kolich + " животных (+ Шрек)\n");
        }
        public static void SortirovkaAge(ref Animal[] mass)
        {
            if (Animal.count == 0)
            {
                Console.WriteLine("\nСортировать нечего!\n");
                return;
            }
            Animal[] dop = new Animal[Animal.count];
            for (int i = 0; i < Animal.count; i++)
            {
                dop[i] = mass[i];
            }
            Array.Sort(dop, new AgeSort());
            for (int i = 0; i < Animal.count; i++)
            {
                mass[i] = dop[i];
            }
            for (int i = 0; i < Animal.count; i++)
            {
                mass[i].Show();
            }
            return;
        }
        public static void PoiskAge(params Animal[] mass)
        {
            if (Animal.count == 0)
            {
                return;
            }
            Console.WriteLine("Введите возраст животного для поиска: ");
            CheckUint(out uint age);
            Animal[] dop = new Animal[Animal.count];
            for (int i = 0; i < Animal.count; i++)
            {
                dop[i] = mass[i];
            }
            int mesto = Array.BinarySearch(dop, new Animal("", "", age), new AgeSort());
            Animal.count--;
            if (mesto < 0) Console.WriteLine("\nЭлемент не найден\n");
            else Console.WriteLine("\nПозиция найденного элемента" + (mesto + 1) + "\n");
        }
        public static void SortirovkaColor(ref Animal[] mass)
        {
            if (Animal.count == 0)
            {
                Console.WriteLine("\nСортировать нечего!\n");
                return;
            }
            Animal[] dop = new Animal[Animal.count];
            for (int i = 0; i < Animal.count; i++)
            {
                dop[i] = mass[i];
            }
            Array.Sort(dop);
            for (int i = 0; i < Animal.count; i++)
            {
                mass[i] = dop[i];
            }
            for (int i = 0; i < Animal.count; i++)
            {
                mass[i].Show();
            }
            return;
        }
        public static void PoiskColor(params Animal[] mass)
        {
            if (Animal.count == 0)
            {
                return;
            }
            Console.WriteLine("Введите цвет животного для поиска: ");
            string color = Console.ReadLine();
            Animal[] dop = new Animal[Animal.count];
            for (int i = 0; i < Animal.count; i++)
            {
                dop[i] = mass[i];
            }
            int mesto = Array.BinarySearch(dop, new Animal("", color, 10));
            Animal.count--;
            if (mesto < 0) Console.WriteLine("\nЭлемент не найден\n");
            else Console.WriteLine("\nПозиция найденного элемента" + (mesto + 1) + "\n");
        }
        static public void Interface()
        {
            int pun = 0;
            Console.WriteLine("Введите количество создаваемых элементов: ");
            CheckUint(out uint n);
            IInit[] massiv = new IInit[n];
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("\n1. Создать просто животное");
                Console.WriteLine("2. Создать млекопитающее");
                Console.WriteLine("3. Создать парнокопытное");
                Console.WriteLine("4. Создать птицу");
                Console.WriteLine("5. Создать город (класс вне иерархии)");
                VyborPunkta(ref pun, 1, 5);
                switch (pun)
                {
                    case 1:
                        Animal a = new Animal();
                        a = (Animal)a.Create();
                        Animal.count -= 2;
                        massiv[i] = a;
                        break;
                    case 2:
                        Mammal m = new Mammal();
                        m = (Mammal)m.Create();
                        Animal.count -= 2;
                        massiv[i] = m;
                        break;
                    case 3:
                        Artiodactyl ar = new Artiodactyl();
                        ar = (Artiodactyl)ar.Create();
                        Animal.count -= 2;
                        massiv[i] = ar;
                        break;
                    case 4:
                        Bird b = new Bird();
                        b = (Bird)b.Create();
                        Animal.count -= 2;
                        massiv[i] = b;
                        break;
                    case 5:
                        Town t = new Town();
                        t = (Town)t.Create();
                        massiv[i] = t;
                        break;
                }
                Console.WriteLine("Элемент успешно создан!");
            }
            for (int i = 0; i < n; i++)
            {
                massiv[i].Show();
            }
        }
        static public void CheckUint(out uint ch)
        {
            uint n;
            bool ok;
            ch = 0;
            do
            {
                string buf = Console.ReadLine();
                ok = uint.TryParse(buf, out n);
                if (ok && n != 0) ch = n;
                else Console.WriteLine("Необходимо ввести натуральное число!");
            } while (!ok || n == 0);
        }
        static public void ChekDouble(out double dou)
        {
            double n;
            bool ok;
            dou = 0;
            do
            {
                string buf = Console.ReadLine();
                ok = double.TryParse(buf, out n);
                if (ok && n != 0) dou = n;
                else Console.WriteLine("Необходимо ввести неотрицательное  число!");
            } while (!ok || n == 0);
        }
        public static void VyborPunkta(ref int switchcase, int min, int max)
        {
            int n;
            bool ok;
            do
            {
                string buf = Console.ReadLine();
                ok = int.TryParse(buf, out n);
                if (ok && n >= min && n <= max) switchcase = n;
                else Console.WriteLine("Выберите, пожалуйста, какой-либо пункт меню");
            } while (!ok || n < min || n > max);
        }
        public static Animal EnterElement()
        {
            int menu = 0;
            Console.WriteLine("\n1. Создать просто животное");
            Console.WriteLine("2. Создать птицу");
            Console.WriteLine("3. Создать парнокопытное");
            Console.WriteLine("4. Создать млекопитающее");
            VyborPunkta(ref menu, 1, 4);
            switch (menu)
            {
                case 1:
                    Console.WriteLine("\nСреда его обитания: ");
                    string sreda = Console.ReadLine();
                    Console.WriteLine("Его цвет: ");
                    string color = Console.ReadLine();
                    Console.WriteLine("Его возраст: ");
                    CheckUint(out uint age);
                    Animal t = new Animal(sreda, color, age);
                    Console.WriteLine("\nЖивотное успешно создано!\n");
                    return t;
                case 2:
                    Console.WriteLine("\nСреда её обитания: ");
                    string sredapt = Console.ReadLine();
                    Console.WriteLine("Её цвет: ");
                    string colorpt = Console.ReadLine();
                    Console.WriteLine("Её возраст: ");
                    CheckUint(out uint agept);
                    Console.WriteLine("Введите её вес: ");
                    CheckUint(out uint weight);
                    Console.WriteLine("Введите размах её крыльев: ");
                    CheckUint(out uint wingspan);
                    Console.WriteLine("Введите пожалуйста её название: ");
                    string namept = Console.ReadLine();
                    Bird b = new Bird(sredapt, colorpt, agept, weight, wingspan, namept);
                    Console.WriteLine("\nПтица успешно создана!\n");
                    return b;
                case 3:
                    Console.WriteLine("\nСреда его обитания: ");
                    string sredaart = Console.ReadLine();
                    Console.WriteLine("Его цвет: ");
                    string colorart = Console.ReadLine();
                    Console.WriteLine("Его возраст: ");
                    CheckUint(out uint ageart);
                    Console.WriteLine("Введите его максимальную скорость бега: ");
                    CheckUint(out uint maxspeed);
                    Console.WriteLine("Введите характеристику его внешнего вида: ");
                    string looklike = Console.ReadLine();
                    Console.WriteLine("Введите пожалуйста его название: ");
                    string nameart = Console.ReadLine();
                    Artiodactyl a = new Artiodactyl(sredaart, colorart, ageart, looklike, maxspeed, nameart);
                    Console.WriteLine("\nПарнокопытное успешно создано!\n");
                    return a;
                case 4:
                    Console.WriteLine("\nСреда его обитания: ");
                    string sredaml = Console.ReadLine();
                    Console.WriteLine("Его цвет: ");
                    string colorml = Console.ReadLine();
                    Console.WriteLine("Его возраст: ");
                    CheckUint(out uint ageml);
                    Console.WriteLine("Введите его отряд: ");
                    string section = Console.ReadLine();
                    Console.WriteLine("Введите его название: ");
                    string nameml = Console.ReadLine();
                    Mammal m = new Mammal(sredaml, colorml, ageml, section, nameml);
                    Console.WriteLine("\nМлекопитающее успешно создано!\n");
                    return m;
            }
            return null;
        }
        public static Animal Create()
        {
            int menu = 0;
            Console.WriteLine("\n1. Создать просто животное");
            Console.WriteLine("2. Создать птицу");
            Console.WriteLine("3. Создать парнокопытное");
            Console.WriteLine("4. Создать млекопитающее");
            VyborPunkta(ref menu, 1, 4);
            switch (menu)
            {
                case 1:
                    Animal a = new Animal();
                    Animal.count--;
                    Animal animal = (Animal)a.Create();
                    Console.WriteLine($"\nЖивотное успешно создано!\n");
                    return animal;
                case 2:
                    Bird b = new Bird();
                    Animal.count--;
                    Bird bird = (Bird)b.Create();
                    Console.WriteLine($"\nПтица успешно создана\n");
                    return bird;
                case 3:
                    Artiodactyl ar = new Artiodactyl();
                    Animal.count--;
                    Artiodactyl art = (Artiodactyl)ar.Create();
                    Console.WriteLine($"\nПарнокопытное успешно создано\n");
                    return art;
                case 4:
                    Mammal m = new Mammal();
                    Animal.count--;
                    Mammal mam = (Mammal)m.Create();
                    Console.WriteLine($"\nМлекопитающее успешно создано\n");
                    return mam;
            }
            return null;
        }
        static public void Start (ref Animal [] mass)
        {
            int punkt = 0;
            do
            {
                Console.WriteLine("1. Создать что-нибудь");
                Console.WriteLine("2. Печать всего, что было создано");
                Console.WriteLine("3. Поиск животных, живущих на болоте");
                Console.WriteLine("4. Поиск птиц с размахом крыльев больше 70 см");
                Console.WriteLine("5. Средняя максимальная скорость парнокопытных");
                Console.WriteLine("6. Работа с интерфейсом IInit");
                Console.WriteLine("7. Сортировка и поиск по цвету");
                Console.WriteLine("8. Сортировка и поиск по возрасту");
                Console.WriteLine("9. Клонированние города");
                Console.WriteLine("10. Копирование города");
                Console.WriteLine("11. Конец работы");
                VyborPunkta(ref punkt, 1, 11);
                switch (punkt)
                {
                    case 1:
                        Console.WriteLine("1. Создать вручную");
                        Console.WriteLine("2. Создать автоматически");
                        int CaseOne = 0;
                        VyborPunkta(ref CaseOne, 1, 2);
                        switch (CaseOne)
                        {
                            case 1:
                                mass[Animal.count] =  EnterElement();
                                break;
                            case 2:
                                mass[Animal.count] = Create();
                                break;
                        }
                        break;
                    case 2:
                        if (Animal.count == 0)
                        {
                            Console.WriteLine("Выводить нечего!\n");
                            break;
                        }
                        int numb = 0;
                        Console.WriteLine("\nС виртуальными методами:");
                        foreach (Animal x in mass)
                        {
                            if (numb < Animal.count)
                            {
                                x.Show();
                            }
                            numb++;
                        }
                        numb = 0;
                        Console.WriteLine("\nБез них:");
                        foreach (Animal x in mass)
                        {
                            if (numb < Animal.count)
                            {
                                x.Appear();
                            }
                            numb++;
                        }
                        break;
                    case 3:
                        PoiskBolota(mass);
                        break;
                    case 4:
                        Wingspan(mass);
                        break;
                    case 5:
                        MaxSpeed(mass);
                        break;
                    case 6:
                        Interface();
                        break;
                    case 7:
                        SortirovkaColor(ref mass);
                        PoiskColor(mass);
                        break;
                    case 8:
                        SortirovkaAge(ref mass);
                        PoiskAge(mass);
                        break;
                    case 9:
                        Town t = new Town();
                        t = (Town)t.Create();
                        Town another = (Town)t.Clone();
                        Console.WriteLine("\nСобственно город: ");
                        t.Show();
                        Console.WriteLine("\nКлон города: ");
                        another.Show();
                        Console.WriteLine("\nУвеличиваем население клону города: ");
                        another.population.PopulationTown = another.population.PopulationTown * 2;
                        Console.WriteLine("\nСобственно город:");
                        t.Show();
                        Console.WriteLine("\nКлон города: ");
                        another.Show();
                        Console.WriteLine();
                        break;
                    case 10:
                        Town c = new Town();
                        t = (Town)c.Create();
                        Town copy = (Town)t.Copy();
                        Console.WriteLine("\nСобственно город: ");
                        t.Show();
                        Console.WriteLine("\nКопия города: ");
                        copy.Show();
                        Console.WriteLine("\nУвеличиваем население копии города: ");
                        copy.population.PopulationTown = copy.population.PopulationTown * 2;
                        Console.WriteLine("\nСобственно город:");
                        t.Show();
                        Console.WriteLine("\nКлон города: ");
                        copy.Show();
                        Console.WriteLine();
                        break;
                    case 11:
                        Console.WriteLine("\nСпасибо за использование!\n");
                        break;
                }
            } while (punkt != 11);
        }
        static void Main(string[] args)
        {
            Animal[] mass = new Animal[25];
            Start(ref mass);
        }
    }
}
