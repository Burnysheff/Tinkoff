﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClassLibrary1;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void AnimalNoParams()
        {
            Animal a = new Animal();
            Assert.AreEqual(a.Age, (uint)10);
        }
        [TestMethod]
        public void AnimalSredaExept()
        {
            Animal a = new Animal(" ", "qwert", 10);
            Assert.AreEqual(a.Sreda, "Не известно");
        }
        [TestMethod]
        public void AnimalColorExept()
        {
            Animal a = new Animal("qwertyu", " ", 10);
            Assert.AreEqual(a.Color, "Не известно");
        }
        [TestMethod]
        public void AnimalAgeExept()
        {
            Animal a = new Animal("qwerty", "qwert", 150);
            Assert.AreEqual(a.Age, (uint)100);
        }
        [TestMethod]
        public void AnimalCreation()
        {
            Animal a = new Animal();
            a = (Animal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void AnimalCompare()
        {
            Animal a = new Animal("asdfgh", "yellow", 10);
            Animal b = new Animal("qwertyu", "yellow", 12);
            int res = a.CompareTo(b);
            Assert.AreEqual(res, 0);
        }
        [TestMethod]
        public void AnimalEquals()
        {
            Animal a = new Animal();
            Animal b = new Animal();
            bool res = a.Equals(b);
            Assert.IsTrue(res);
        }
        [TestMethod]
        public void MammalEquals ()
        {
            Mammal a = new Mammal();
            Mammal b = new Mammal();
            bool res = a.Equals(b);
            Assert.IsTrue(res);
        }
        [TestMethod]
        public void MammalSectionExept()
        {
            Mammal a = new Mammal("asdfgh", "yellow", 10, "qwertyui", " ");
            Assert.AreEqual(a.Section, "Не известен");
        }
        [TestMethod]
        public void MammalNameExept()
        {
            Mammal a = new Mammal("asdfgh", "yellow", 10, " ", "qwertyu");
            Assert.AreEqual(a.Name, "Не известно");
        }
        [TestMethod]
        public void MammalCreate()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate1()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate2()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate3()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate4()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate5()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate6()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate7()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate8()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate9()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate10()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate11()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate12()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate13()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate14()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate15()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void MammalCreate16()
        {
            Mammal a = new Mammal();
            a = (Mammal)a.Create();
            bool ok = a.Age < 31 && a.Age > 0;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void BirdEquals()
        {
            Bird a = new Bird();
            Bird b = new Bird();
            bool ok = a.Equals(b);
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void BirdNameExept()
        {
            Bird a = new Bird("qwerty", "qwertyu", 10, 10, 10, " ");
            Assert.AreEqual(a.Name, "Не известно");
        }
        [TestMethod]
        public void BirdWeightExept()
        {
            Bird a = new Bird("qwerty", "qwertyu", 10, 1234, 10, "qwertyu");
            Assert.AreEqual(a.Weight, (uint)100);
        }
        [TestMethod]
        public void BirdSpanExept()
        {
            Bird a = new Bird("qwerty", "qwertyu", 10, 10, 2000, "qwertyu");
            Assert.AreEqual(a.Wingspan, (uint)300);
        }
        [TestMethod]
        public void BirdCreate()
        {
            Bird a = new Bird("qwerty", "qwertyu", 10, 10, 2000, "qwertyu");
            a = (Bird)a.Create();
            bool ok = a.Age > 0 && a.Age < 31;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void ArtEquals()
        {
            Artiodactyl a = new Artiodactyl();
            Artiodactyl b = new Artiodactyl();
            bool ok = a.Equals(b);
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void ArtNameExept()
        {
            Artiodactyl a = new Artiodactyl("qwertyui", "qwertyui", 10, "qwertyui", 80, " ");
            Assert.AreEqual(a.Name, "Не известно");
        }
        [TestMethod]
        public void ArtSpeedExept()
        {
            Artiodactyl a = new Artiodactyl("qwertyui", "qwertyui", 10, "qwertyui", 500, "qwertyuio");
            Assert.AreEqual(a.MaxSpeed, (uint)120);
        }
        [TestMethod]
        public void ArtLookExept()
        {
            Artiodactyl a = new Artiodactyl("qwertyui", "qwertyui", 10, " ", 80, "qwertyu");
            Assert.AreEqual(a.Looklike, "Не понятно");
        }
        [TestMethod]
        public void ArtCreate()
        {
            Artiodactyl a = new Artiodactyl("qwerty", "qwertyu", 10 , "qwertyu", 2000, "qwertyu");
            a = (Artiodactyl)a.Create();
            bool ok = a.Age > 0 && a.Age < 31;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void TownNoParams()
        {
            Town a = new Town();
            Assert.AreEqual(a.Name, "Moscow");
        }
        [TestMethod]
        public void TownParams()
        {
            Town a = new Town(100, "Paris");
            Assert.AreEqual(a.Name, "Paris");
        }
        [TestMethod]
        public void TownCreate()
        {
            Town a = new Town(100, "Paris");
            a = (Town)a.Create();
            bool ok = a.population.PopulationTown > 0 && a.population.PopulationTown < 1000001;
            Assert.IsTrue(ok);
        }
        [TestMethod]
        public void TownClone()
        {
            Town a = new Town(100, "Paris");
            Town b = (Town)a.Clone();
            b.population.PopulationTown = b.population.PopulationTown * 2;
            Assert.AreNotEqual(a.population.PopulationTown, b.population.PopulationTown);
        }
        [TestMethod]
        public void TownCopy()
        {
            Town a = new Town(100, "Paris");
            Town b = (Town)a.Copy();
            b.population.PopulationTown = b.population.PopulationTown * 2;
            Assert.AreEqual(a.population.PopulationTown, b.population.PopulationTown);
        }
    }
}
