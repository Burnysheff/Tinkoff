﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Mammal: Animal, IInit
    {
        Random rnd = new Random();
        private string name;
        private string section;
        public string Name
        {
            get { return name; }
            set
            {
                if (value.Trim() == "")
                {
                    Console.WriteLine("\nНазвание млекопитающего не указано!");
                    name = "Не известно";
                }
                else name = value;
            }
        }
        public string Section
        {
            get { return section; }
            set
            {
                if (value.Trim() == "")
                {
                    Console.WriteLine("\nОтряд не указан!");
                    section = "Не известен";
                }
                else section = value;
            }
        }
        public Mammal() : base()
        {
            Name = "Морж";
            Section = "Ластоногие";
        }
        public Mammal (string sreda, string color, uint age, string name, string section) : base(sreda, color, age)
        {
            Name = name;
            Section = section;
        }
        public override object Create()
        {
            string name = "";
            Animal p = (Animal)base.Create();
            Animal.count--;
            string[] sections = { "Насекомоядное", "Рукокрылое", "Грызун", "Зайцеобразное", "Хищное", "Ластоногое", "Примат" };
            string section = sections[rnd.Next(sections.Length)];
            if (section == "Насекомоядное")
            {
                string[] names = { "Ёж", "Крот", "Многозубка" };
                name = names[rnd.Next(names.Length)];
            }
            if (section == "Рукокрылое")
            {
                string[] names = { "Летучая мышь" };
                name = names[rnd.Next(names.Length)];
            }
            if (section == "Грызун")
            {
                string[] names = { "Мышь", "Крыса", "Белка" };
                name = names[rnd.Next(names.Length)];
            }
            if (section == "Зайцеобразное")
            {
                string[] names = { "Заяц", "Кролик" };
                name = names[rnd.Next(names.Length)];
            }
            if (section == "Хищное")
            {
                string[] names = { "Лев", "Волк", "Тигр", "Медведь" };
                name = names[rnd.Next(names.Length)];
            }
            if (section == "Ластоногое")
            {
                string[] names = { "Морж", "Тюлень", "Морской слон" };
                name = names[rnd.Next(names.Length)];
            }
            if (section == "Примат")
            {
                string[] names = { "Человек", "Горилла", "Орангутанг" };
                name = names[rnd.Next(names.Length)];
            }
            Mammal s = new Mammal(p.Sreda, p.Color, p.Age, name, section);
            return s;
        }
        new public void Appear()
        {
            Console.WriteLine("\nКласс: млекопитающие\nСреда его обитания: " + Sreda + "\nЕго цвет: " + Color + "\nВозраст животного: " + Age + " лет" + "\nЕго отряд: " + Section + "\nНазвание животного: " + Name + "\n");
        }
        override public void Show()
        {
            Console.WriteLine("\nКласс: млекопитающие\nСреда его обитания: " + Sreda + "\nЕго цвет: " + Color + "\nВозраст животного: " + Age + " лет" + "\nЕго отряд: " + Section + "\nНазвание животного: " + Name + "\n");
        }
        public override bool Equals(object obj)
        {
            return base.Equals(obj) && (((Mammal)obj).Name == this.Name) && (((Mammal)obj).Section == this.Section);
        }
    }
}
