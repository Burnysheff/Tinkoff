﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class AgeSort: IComparer
    {
        public int Compare(object obj1, object obj2)
        {
            if (((Animal)obj1).Age > ((Animal)obj2).Age) return 1;
            if (((Animal)obj1).Age < ((Animal)obj2).Age) return -1;
            return 0;
        }
    }
}
