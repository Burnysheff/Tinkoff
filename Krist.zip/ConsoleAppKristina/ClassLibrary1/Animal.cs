﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Animal: IInit, IComparable
    {
        Random rnd = new Random();
        private string sreda;
        private string color;
        private uint age;
        public static int count;
        public string Sreda
        {
            get { return sreda; }
            set
            {
                if (value.Trim() == "")
                {
                    Console.WriteLine("\nСреда обитания не указана!");
                    sreda = "Не известно";
                }
                else sreda = value;
            }
        }
        public string Color
        {
            get { return color; }
            set
            {
                if (value.Trim() == "")
                {
                    Console.WriteLine("\nЦвет не указан!");
                    color = "Не известно";
                }
                else color = value;
            }
        }
        public uint Age
        {
            get { return age; }
            set
            {
                if (value > 100)
                {
                    Console.WriteLine("\nТакого не может быть, максимальный возраст - 100 лет!\n");
                    age = 100;
                }
                else age = value;
            }
        }
        public Animal(string sreda, string color, uint age)
        {
            count++;
            Sreda = sreda;
            Color = color;
            Age = age;
        }
        public Animal()
        {
            count++;
            Sreda = "plain";
            Color = "Grey";
            Age = 10;
        }
        public virtual object Create()
        {
            string[] colors = { "Green", "Red", "White", "Black", "Yellow", "Grey", "Blue", "Brown" };
            string[] places = { "plain", "valley", "forest", "swamp", "mointains", "desert" };
            string color = colors[rnd.Next(colors.Length)];
            string place = places[rnd.Next(places.Length)];
            Animal an = new Animal(place, color, (uint)rnd.Next(1, 30));
            return an;
        }
        public int CompareTo(object obj)
        {
            return string.Compare(this.Color, ((Animal)obj).Color);
        }
        public override bool Equals(object obj)
        {
            return (this.Color == ((Animal)obj).Color && this.Sreda == ((Animal)obj).Sreda && this.Age == ((Animal)obj).Age);
        }
        public void Appear()
        {
            Console.WriteLine("\nКласс: животное\nСреда его обитания: " + Sreda + "\nЕго цвет: " + Color + "\nВозраст животного: " + Age + "\n");
        }
        virtual public void Show()
        {
            Console.WriteLine("\nКласс: животное\nСреда его обитания: " + Sreda + "\nЕго цвет: " + Color + "\nВозраст животного: " + Age + "\n");
        }
    }
}
