﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Artiodactyl: Animal, IInit
    {
        Random rnd = new Random();
        private string looklike;
        private uint maxspeed;
        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                if (value.Trim() == "")
                {
                    Console.WriteLine("\nНазвание парнокопытного не указано!");
                    name = "Не известно";
                }
                else name = value;
            }
        }
        public uint MaxSpeed
        {
            get { return maxspeed; }
            set
            {
                if (value > 120)
                {
                    Console.WriteLine("\nТакого не может быть, максимальная скорость - 120 км/ч!\n");
                    maxspeed = 120;
                }
                else maxspeed = value;
            }
        }
        public string Looklike
        {
            get { return looklike; }
            set
            {
                if (value.Trim() == "")
                {
                    Console.WriteLine("\nНе понятно как выглядит...");
                    looklike = "Не понятно";
                }
                else looklike = value;
            }
        }
        public Artiodactyl() : base()
        {
            Looklike = "Необычно";
            MaxSpeed = 40;
            Name = "Жираф";
        }
        public Artiodactyl(string sreda, string color, uint age, string looklike, uint maxspeed, string name) : base(sreda, color, age)
        {
            Looklike = looklike;
            MaxSpeed = maxspeed;
            Name = name;
        }
        public override object Create()
        {
            Animal p = (Animal)base.Create();
            Animal.count--;
            string [] looklikes = { "Страшно", "Мило", "Смешно", "Странно", "Необычно", "Угрожающе", "Удивительно" };
            string[] names = { "Зубр", "Жираф", "Корова", "Антилопа", "Лощадь", "Носорог", "Свинья", "Бегемот" };
            Artiodactyl b = new Artiodactyl(p.Sreda, p.Color, p.Age, looklikes[rnd.Next(looklikes.Length)], (uint)rnd.Next(80), names[rnd.Next(names.Length)]);
            return b;
        }
        new public void Appear()
        {
            Console.WriteLine("\nКласс: парнокопытные\nСреда его обитания: " + Sreda + "\nЕго цвет: " + Color + "\nВозраст животного: " + Age + " лет" + "\nВыглядит он: " + Looklike + "\nЕго максимальная скорость: " + MaxSpeed + "\nНазвание животного: " + Name + "\n");
        }
        override public void Show()
        {
            Console.WriteLine("\nКласс: парнокопытные\nСреда его обитания: " + Sreda + "\nЕго цвет: " + Color + "\nВозраст животного: " + Age + " лет" + "\nВыглядит он: " + Looklike + "\nЕго максимальная скорость: " + MaxSpeed + "\nНазвание животного: " + Name + "\n");
        }
        public override bool Equals(object obj)
        {
            return base.Equals(obj) && (((Artiodactyl)obj).Name == this.Name) && (((Artiodactyl)obj).MaxSpeed == this.MaxSpeed && ((Artiodactyl)obj).Looklike == this.Looklike);
        }
    }
}
