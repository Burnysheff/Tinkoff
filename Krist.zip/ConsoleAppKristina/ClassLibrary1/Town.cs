﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Town: IInit
    {
        Random rnd = new Random();
        public Population population;
        public string Name { get; set; }
        public Town()
        {
            population = new Population(1000);
            Name = "Moscow";
        }
        public Town(uint pop, string name)
        {
            population = new Population(pop);
            Name = name;
        }
        public object Create()
        {
            string[] names = { "Saint Petersberg", "London", "Perm", "Rome", "New York", "Lima", "Oslo", "Cairo", "Manchester" };
            Town t = new Town((uint)rnd.Next(1000000), names[rnd.Next(names.Length)]);
            return t;
        }
        public void Show()
        {
            Console.WriteLine("\nНазвание города: " + Name + "\nЕго население: " + population.PopulationTown + "\n");
        }
        public object Clone()
        {
            return new Town(this.population.PopulationTown, this.Name);
        }
        public object Copy()
        {
            return (Town)this.MemberwiseClone();
        }
    }
}
