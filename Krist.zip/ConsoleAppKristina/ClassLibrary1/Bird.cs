﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Bird: Animal, IInit
    {
        Random rnd = new Random();
        private uint weight;
        private uint wingspan;
        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                if (value.Trim() == "")
                {
                    Console.WriteLine("\nНазвание птицы не указано!");
                    name = "Не известно";
                }
                else name = value;
            }
        }
        public uint Weight
        {
            get { return weight; }
            set
            {
                if (value > 100)
                {
                    Console.WriteLine("\nТакого не может быть, максимальный вес - 100 кг!\n");
                    weight = 100;
                }
                else weight = value;
            }
        }
        public uint Wingspan
        {
            get { return wingspan; }
            set
            {
                if (value > 300)
                {
                    Console.WriteLine("\nТакого не может быть, максимальный размах крыльев - 300 сантиметров!\n");
                    wingspan = 300;
                }
                else wingspan = value;
            }
        }
        public Bird(string sreda, string color, uint age, uint weight, uint wingspan, string name) : base(sreda, color, age)
        {
            Weight = weight;
            Wingspan = wingspan;
            Name = name;
        }
        public Bird() : base()
        {
            Weight = 5;
            Wingspan = 30;
            Name = "Попугай";
        }
        public override object Create()
        {
            Animal p = (Animal)base.Create();
            Animal.count--;
            string[] mas = { "Воробей", "Цапля", "Альбатрос", "Орёл", "Попугай", "Журавль", "Аист" };
            Bird b = new Bird(p.Sreda, p.Color, p.Age, (uint)rnd.Next(20), (uint)rnd.Next(150), mas[rnd.Next(mas.Length)]);
            return b;
        }
        new public void Appear()
        {
            Console.WriteLine("\nКласс: птицы\nСреда его обитания: " + Sreda + "\nЕго цвет: " + Color + "\nВозраст животного: " + Age + " лет" + "\nЕго вес: " + Weight + " килограмм" + "\nРазмах его крыльев: " + Wingspan + " сантиметров" + "\nНазвание животного: " + Name + "\n");
        }
        override public void Show()
        {
            Console.WriteLine("\nКласс: птицы\nСреда его обитания: " + Sreda + "\nЕго цвет: " + Color + "\nВозраст животного: " + Age + " лет" + "\nЕго вес: " + Weight + " килограмм" + "\nРазмах его крыльев: " + Wingspan + " сантиметров" + "\nНазвание животного: " + Name + "\n");
        }
        public override bool Equals(object obj)
        {
            return base.Equals(obj) && (((Bird)obj).Name == this.Name) && (((Bird)obj).Wingspan == this.Wingspan && ((Bird)obj).Weight == this.Weight);
        }
    }
}
