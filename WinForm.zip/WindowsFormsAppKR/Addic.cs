﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsAppKR
{
    public partial class Addic : Form
    {
        public Name Owner;
        public Addic()
        {
            InitializeComponent();
        }

        private void Beginning_Click(object sender, EventArgs e)
        {
            FileStream f = new FileStream(Owner.textBox1.Text, FileMode.Open);
            BinaryReader b = new BinaryReader(f);
            List<string> mas = new List<string>();
            try
            {
                while (true)
                {
                    mas.Add(b.ReadString());
                }
            }
            catch (EndOfStreamException)
            {
            }
            b.Close();
            f.Close();
            if (listBox1.SelectedItem.ToString() == "Автоматически")
            {
                FileStream fq = new FileStream(Owner.textBox1.Text, FileMode.Create);
                BinaryWriter bq = new BinaryWriter(fq);
                Gener gen = new Gener();
                bq.Write(gen.Name);
                bq.Write(gen.Adress);
                bq.Write(gen.Number.ToString());
                bq.Write(gen.Edu);
                bq.Write(gen.Ord.ToString());
                bq.Write("\n");
                for (int i = 0; i < mas.Count; i++)
                {
                    bq.Write(mas[i]);
                }
                bq.Close();
                fq.Close();

            }
            else
            {
                FileStream fq = new FileStream(Owner.textBox1.Text, FileMode.Create);
                BinaryWriter bq = new BinaryWriter(fq);
                Hand han = new Hand();
                han.ShowDialog();
                if (han.DialogResult == DialogResult.OK)
                {
                    bq.Write(han.Nameq.Text);
                    bq.Write(han.Adress.Text);
                    bq.Write(han.Phone.Text);
                    bq.Write(han.Edu.Text);
                    bq.Write(han.Ord.Text);
                    bq.Write("\n");
                }
                for (int i = 0; i < mas.Count; i++)
                {
                    bq.Write(mas[i]);
                }
                bq.Close();
                fq.Close();
            }
            b.Close();
            f.Close();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Beginning.Enabled = true;
            Ending.Enabled = true;
        }

        private void Ending_Click(object sender, EventArgs e)
        {
            FileStream f = new FileStream(Owner.textBox1.Text, FileMode.Open);
            BinaryReader b = new BinaryReader(f);
            List<string> mas = new List<string>();
            try
            {
                while (true)
                {
                    mas.Add(b.ReadString());
                }
            }
            catch (EndOfStreamException)
            {
            }
            b.Close();
            f.Close();
            if (listBox1.SelectedItem.ToString() == "Автоматически")
            {
                FileStream fq = new FileStream(Owner.textBox1.Text, FileMode.Create);
                BinaryWriter bq = new BinaryWriter(fq);
                Gener gen = new Gener();
                for (int i = 0; i < mas.Count; i++)
                {
                    bq.Write(mas[i]);
                }
                bq.Write(gen.Name);
                bq.Write(gen.Adress);
                bq.Write(gen.Number.ToString());
                bq.Write(gen.Edu);
                bq.Write(gen.Ord.ToString());
                bq.Write("\n");
                bq.Close();
                fq.Close();
            }
            else
            {
                FileStream fq = new FileStream(Owner.textBox1.Text, FileMode.Create);
                BinaryWriter bq = new BinaryWriter(fq);
                Hand han = new Hand();
                han.ShowDialog();
                if (han.DialogResult == DialogResult.OK)
                {
                    for (int i = 0; i < mas.Count; i++)
                    {
                        bq.Write(mas[i]);
                    }
                    bq.Write(han.Nameq.Text);
                    bq.Write(han.Adress.Text);
                    bq.Write(han.Phone.Text);
                    bq.Write(han.Edu.Text);
                    bq.Write(han.Ord.Text);
                    bq.Write("\n");
                }
                bq.Close();
                fq.Close();
            }
            b.Close();
            f.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0)
            {
                if (int.TryParse(textBox1.Text, out int n) == true)
                {
                    if (n > 0)
                    {
                        FileStream f = new FileStream(Owner.textBox1.Text, FileMode.Open);
                        BinaryReader b = new BinaryReader(f);
                        List<string> mas = new List<string>();
                        try
                        {
                            while (true)
                            {
                                mas.Add(b.ReadString());
                            }
                        }
                        catch (EndOfStreamException)
                        {
                        }
                        b.Close();
                        f.Close();
                        if ((n - 1) <= (mas.Count / 6))
                        {
                            Ok.Enabled = true;
                        }
                        else Ok.Enabled = false;
                    }
                    else Ok.Enabled = false;
                }
                else Ok.Enabled = false;
            }
            else Ok.Enabled = false;
        }

        private void Ok_Click(object sender, EventArgs e)
        {
            int.TryParse(textBox1.Text, out int n);
            FileStream f = new FileStream(Owner.textBox1.Text, FileMode.Open);
            BinaryReader b = new BinaryReader(f);
            List<string> mas = new List<string>();
            try
            {
                while (true)
                {
                    mas.Add(b.ReadString());
                }
            }
            catch (EndOfStreamException)
            {
            }
            b.Close();
            f.Close();
            FileStream g = new FileStream(Owner.textBox1.Text, FileMode.Open);
            BinaryWriter bi = new BinaryWriter(g);
            if (listBox1.SelectedItem.ToString() == "Автоматически")
            {
                for (int i = 0; i < (n - 1) * 6; i++)
                {
                    bi.Write(mas[i]);
                }
                Gener gen = new Gener();
                bi.Write(gen.Name);
                bi.Write(gen.Adress);
                bi.Write(gen.Number.ToString());
                bi.Write(gen.Edu);
                bi.Write(gen.Ord.ToString());
                bi.Write("\n");
                for (int i = (n - 1) * 6; i < mas.Count; i++)
                {
                    bi.Write(mas[i]);
                }
            }
            else
            {
                Hand han = new Hand();
                han.ShowDialog();
                if (han.DialogResult == DialogResult.OK)
                {
                    for (int i = 0; i < (n - 1) * 6; i++)
                    {
                        bi.Write(mas[i]);
                    }
                    bi.Write(han.Nameq.Text);
                    bi.Write(han.Adress.Text);
                    bi.Write(han.Phone.Text);
                    bi.Write(han.Edu.Text);
                    bi.Write(han.Ord.Text);
                    bi.Write("\n");
                    for (int i = (n - 1) * 6; i < mas.Count; i++)
                    {
                        bi.Write(mas[i]);
                    }
                }
            }
            bi.Close();
            g.Close();
        }
    }
}
