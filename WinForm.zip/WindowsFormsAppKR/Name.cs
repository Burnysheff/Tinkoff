﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsAppKR
{
    public partial class Name : Form
    {
        static Random rnd = new Random();
        int iter = 0;
        public string Reason;
        public string Form;
        public Name()
        {
            InitializeComponent();
        }

        private void Name_Load(object sender, EventArgs e)
        {
            if (Reason == "WatchAll")
            {
                Answer ans = new Answer();
                List<string> mas = new List<string>();
                for (int i = 0; i < Form1.names.Count; i++)
                {
                    FileStream f = new FileStream(Form1.names[i], FileMode.Open);
                    BinaryReader b = new BinaryReader(f);
                    mas.Add("\n");
                    mas.Add(Form1.names[i]);
                    mas.Add("\n");
                    try
                    {
                        while (true)
                        {
                            mas.Add(b.ReadString());
                        }
                    }
                    catch (EndOfStreamException)
                    {
                    }
                    if (mas.Count == 0)
                    {
                        ans.label1.Text = "Файл пустой!";
                    }
                    for (int q = 0; q < mas.Count; q++)
                    {
                        ans.label1.Text = ans.label1.Text + ", " + mas[q];
                    }
                    b.Close();
                    f.Close();
                    mas.Clear();
                }
                ans.ShowDialog();
                DialogResult = DialogResult.OK;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (this.Reason == "Create")
            {
                if (Number.Text.Length != 0)
                {
                    if (int.TryParse(Number.Text, out int n) == true)
                    {
                        if (n > 0)
                        {
                            if (textBox1.Text.Length != 0 && (Form1.names.Contains(textBox1.Text) == false))
                            {
                                label3.Text = "Такого файла не существует!";
                                label3.Visible = false;
                                OK.Enabled = true;
                                iter = n;
                            }
                            if (textBox1.Text.Length == 0)
                            {
                                OK.Enabled = false;
                            }
                            if (Form1.names.Contains(textBox1.Text) == true) 
                            {
                                label3.Text = "Такой файл уже есть!";
                                label3.Visible = true;
                                OK.Enabled = false;
                            }
                            else
                            {
                                label3.Visible = false;
                            }
                        }
                        else OK.Enabled = false;
                    }
                    else OK.Enabled = false;
                }
                else OK.Enabled = false;
            }
            if (this.Reason == "Watch")
            {
                if (Form1.names.Contains(textBox1.Text) == false)
                {
                    label3.Visible = true;
                    OK.Enabled = false;
                }
                else
                {
                    label3.Visible = false;
                    OK.Enabled = true;
                }
            }
            if (this.Reason == "Add")
            {
                if (Form1.names.Contains(textBox1.Text) == false)
                {
                    label3.Visible = true;
                    OK.Enabled = false;
                }
                else
                {
                    label3.Visible = false;
                    OK.Enabled = true;
                }
            }
            if (this.Reason == "Delete")
            {
                if (Form1.names.Contains(textBox1.Text) == false)
                {
                    label3.Visible = true;
                    OK.Enabled = false;
                }
                else
                {
                    OK.Enabled = true;
                    label3.Visible = false;
                }
            }
            if (this.Reason == "Change")
            {
                if (Form1.names.Contains(textBox1.Text) == false)
                {
                    label3.Visible = true;
                    OK.Enabled = false;
                }
                else
                {
                    OK.Enabled = true;
                    label3.Visible = false;
                }
            }
            if (this.Reason == "All")
            {
                if (textBox1.Text.Length != 0)
                {
                    if (int.TryParse(textBox1.Text, out int n) == true)
                    {
                        if (n > 0)
                        {
                            OK.Enabled = true;
                        }
                        else OK.Enabled = false;
                    }
                    else OK.Enabled = false;
                }
                else OK.Enabled = false;
            }
            if (this.Reason == "Edu")
            {
                if (textBox1.Text.Length != 0)
                {
                    if (int.TryParse(textBox1.Text, out int n) == true)
                    {
                        if (n > 0)
                        {
                            OK.Enabled = true;
                        }
                        else OK.Enabled = false;
                    }
                    else OK.Enabled = false;
                }
                else OK.Enabled = false;
            }
            if (this.Reason == "linq")
            {
                if (textBox1.Text.Length != 0)
                {
                    if (Form1.names.Contains(textBox1.Text) == false)
                    {
                        OK.Enabled = false;
                        label3.Visible = true;
                    }
                    else
                    {
                        OK.Enabled = true;
                        label3.Text = "Такого файла еще нет!";
                        label3.Visible = false;
                    }
                }
                else
                {
                    OK.Enabled = false;
                    label3.Visible = false;

                }
            }
        }

        private void OK_Click(object sender, EventArgs e)
        {
            if (this.Reason == "WatchAll")
            {
                return;
            }
            if (this.Reason == "Create")
            {
                Form1.names.Add(this.textBox1.Text);
                if (this.Form == "Автоматически")
                {
                    FileStream f = new FileStream(this.textBox1.Text, FileMode.Create);
                    BinaryWriter b = new BinaryWriter(f);
                    for (int i = 0; i < iter; i++)
                    {
                        Gener gen = new Gener();
                        b.Write(gen.Name);
                        b.Write(gen.Adress);
                        b.Write(gen.Number.ToString());
                        b.Write(gen.Edu);
                        b.Write(gen.Ord.ToString());
                        b.Write("\n");
                    }
                    b.Close();
                    f.Close();
                }
                else
                {
                    FileStream f = new FileStream(this.textBox1.Text, FileMode.Create);
                    BinaryWriter b = new BinaryWriter(f);
                    Hand han = new Hand();
                    for (int i = 0; i < iter; i++)
                    {
                        han.ShowDialog();
                        if (han.DialogResult == DialogResult.OK)
                        {
                            b.Write(han.Nameq.Text);
                            b.Write(han.Adress.Text);
                            b.Write(han.Phone.Text);
                            b.Write(han.Edu.Text);
                            b.Write(han.Ord.Text);
                            b.Write("\n");
                        }
                    }
                    b.Close();
                    f.Close();
                }
            }
            if (Reason == "Watch")
            {
                int j = 0;
                List<string> mas = new List<string>();
                Answer ans = new Answer();
                FileStream f = new FileStream(this.textBox1.Text, FileMode.Open);
                BinaryReader b = new BinaryReader(f);
                try
                {
                    while (true)
                    {
                        mas.Add(b.ReadString());
                        j++;
                    }
                }
                catch (EndOfStreamException)
                {
                }
                if (mas.Count == 0)
                {
                    ans.label1.Text = "Файл пустой!";
                }
                for (int i = 0; i < mas.Count; i++)
                {
                    ans.label1.Text = ans.label1.Text + ", " + mas[i];
                }
                ans.ShowDialog();
                b.Close();
                f.Close();
            }
            if (Reason == "Add")
            {
                Addic ad = new Addic();
                ad.Owner = this;
                ad.ShowDialog();
            }
            if (Reason == "Delete")
            {
                label2.Text = "Введите позицию для удаления";
                label2.Visible = true;
                Number.Visible = true;
                DialogResult = DialogResult.None;
                OK.Enabled = false;
            }
            if (Reason == "Change")
            {
                label2.Text = "Введите позицию для замены";
                label2.Visible = true;
                Number.Visible = true;
                DialogResult = DialogResult.None;
                OK.Enabled = false;
                listBox1.Visible = true;
                OK.Visible = false;
            }
            if (Reason == "All")
            {
                int j;
                Answer ans = new Answer();
                List<string> mas = new List<string>();
                List<string> mass = new List<string>();
                for (int i = 0; i < Form1.names.Count; i++)
                {
                    j = 0;
                    FileStream f = new FileStream(Form1.names[i], FileMode.Open);
                    BinaryReader b = new BinaryReader(f);
                    try
                    {
                        while (true)
                        {
                            mas.Add(b.ReadString());
                            j++;
                            if ((j + 1) % 6 == 0 && mas[mas.Count - 1] == textBox1.Text)
                            {
                                mass.Add(mas[mas.Count - 5]);
                                mass.Add(mas[mas.Count - 4]);
                                mass.Add(mas[mas.Count - 3]);
                                mass.Add(mas[mas.Count - 2]);
                                mass.Add(mas[mas.Count - 1]);
                                mass.Add("\n");
                            }
                        }
                    }
                    catch (EndOfStreamException)
                    {
                    }
                    for (int q = 0; q < mass.Count; q++)
                    {
                        ans.label1.Text = ans.label1.Text + ", " + mass[q];
                    }
                    b.Close();
                    f.Close();
                    mas.Clear();
                }
                ans.ShowDialog();
            }
            if (Reason == "Edu")
            {
                int res = 0;
                int j;
                Answer ans = new Answer();
                List<string> mas = new List<string>();
                List<string> mass = new List<string>();
                for (int i = 0; i < Form1.names.Count; i++)
                {
                    j = 0;
                    FileStream f = new FileStream(Form1.names[i], FileMode.Open);
                    BinaryReader b = new BinaryReader(f);
                    try
                    {
                        while (true)
                        {
                            mas.Add(b.ReadString());
                            j++;
                            if ((j + 1) % 6 == 0 && mas[mas.Count - 1] == textBox1.Text && mas[mas.Count - 2] == "High")
                            {
                                res++;
                            }
                        }
                    }
                    catch (EndOfStreamException)
                    {
                    }
                    b.Close();
                    f.Close();
                    mas.Clear();
                }
                ans.label1.Text = $"{res} таких человек";
                if (res == 0)
                {
                    ans.label1.Text = $"Таких людей нет!";
                }
                ans.ShowDialog();
            }
            if (Reason == "linq")
            {
                string[] mas = { "a", "b", "c", "d", "e", "f", "q", "w", "r", "t", "y", "u", "i", "o", "p", "s", "h", "j" };
                string Text = mas[rnd.Next(mas.Length)] + mas[rnd.Next(mas.Length)] + mas[rnd.Next(mas.Length)];
                Form1.zaq = Text;
                FileStream f = new FileStream(textBox1.Text, FileMode.Open);
                BinaryReader b = new BinaryReader(f);
                List<string> masq = new List<string>();
                List<string> masp = new List<string>();
                int j = 0;
                try
                {
                    while (true)
                    {
                        masq.Add(b.ReadString());
                        j++;
                        if (j % 6 == 1)
                        {
                            masp.Add(masq[masq.Count - 1]);
                        }
                    }
                }
                catch (EndOfStreamException)
                {
                }
                b.Close();
                f.Close();
                IEnumerable<string> qwer = from s in masp where (s == "Krasnova" || s == "Belova" || s == "Chernova" || s == "Petrova" || s == "Ivanova") orderby s select s;
                StreamWriter fq = new StreamWriter(Text);
                fq.WriteLine($"Результат запроса в {textBox1.Text}");
                fq.WriteLine(qwer.Count() + " элементов\n");
                fq.Close();
            }
        }

        private void Number_TextChanged(object sender, EventArgs e)
        {
            if (this.Reason == "Create")
            {
                if (Number.Text.Length != 0)
                {
                    if (int.TryParse(Number.Text, out int n) == true)
                    {
                        if (n > 0)
                        {
                            if (textBox1.Text.Length != 0 && (Form1.names.Contains(textBox1.Text) == false))
                            {
                                label3.Text = "Такого файла не существует!";
                                label3.Visible = false;
                                OK.Enabled = true;
                                iter = n;
                            }
                            if (textBox1.Text.Length == 0)
                            {
                                OK.Enabled = false;
                            }
                            if (Form1.names.Contains(textBox1.Text) == true)
                            {
                                label3.Text = "Такой файл уже есть!";
                                label3.Visible = true;
                                OK.Enabled = false;
                            }
                            else
                            {
                                label3.Visible = false;
                            }
                        }
                        else OK.Enabled = false;
                    }
                    else OK.Enabled = false;
                }
                else OK.Enabled = false;
            }
            if (this.Reason == "Delete")
            {
                if (Number.Text.Length != 0)
                {
                    if (int.TryParse(Number.Text, out int n) == true)
                    {
                        if (n > 0)
                        {
                            FileStream f = new FileStream(textBox1.Text, FileMode.Open);
                            BinaryReader b = new BinaryReader(f);
                            List<string> mas = new List<string>();
                            try
                            {
                                while (true)
                                {
                                    mas.Add(b.ReadString());
                                }
                            }
                            catch (EndOfStreamException)
                            {
                            }
                            b.Close();
                            f.Close();
                            if ((n) <= (mas.Count / 6))
                            {
                                Ready.Enabled = true;
                                Ready.Visible = true;
                            }
                            else Ready.Enabled = false;
                        }
                        else Ready.Enabled = false;
                    }
                    else Ready.Enabled = false;
                }
                else Ready.Enabled = false;
            }
            if (this.Reason == "Change")
            {
                if (Number.Text.Length != 0)
                {
                    if (int.TryParse(Number.Text, out int n) == true)
                    {
                        if (n > 0)
                        {
                            if (listBox1.GetSelected(0) == true || listBox1.GetSelected(1) == true)
                            {
                                FileStream f = new FileStream(textBox1.Text, FileMode.Open);
                                BinaryReader b = new BinaryReader(f);
                                List<string> mas = new List<string>();
                                try
                                {
                                    while (true)
                                    {
                                        mas.Add(b.ReadString());
                                    }
                                }
                                catch (EndOfStreamException)
                                {
                                }
                                b.Close();
                                f.Close();
                                if ((n) <= (mas.Count / 6))
                                {
                                    Ready.Enabled = true;
                                    Ready.Visible = true;
                                }
                                else Ready.Enabled = false;
                            }
                            else Ready.Enabled = false;
                        }
                        else Ready.Enabled = false;
                    }
                    else Ready.Enabled = false;
                }
                else Ready.Enabled = false;
            }
        }

        private void Ready_Click(object sender, EventArgs e)
        {
            if (Reason == "Delete")
            {
                int.TryParse(Number.Text, out int n);
                FileStream f = new FileStream(textBox1.Text, FileMode.Open);
                BinaryReader b = new BinaryReader(f);
                List<string> mas = new List<string>();
                try
                {
                    while (true)
                    {
                        mas.Add(b.ReadString());
                    }
                }
                catch (EndOfStreamException)
                {
                }
                b.Close();
                f.Close();
                FileStream g = new FileStream(textBox1.Text, FileMode.Create);
                BinaryWriter bi = new BinaryWriter(g);
                for (int i = 0; i < (n - 1) * 6; i++)
                {
                    bi.Write(mas[i]);
                }
                for (int i = (n * 6); i < mas.Count; i++)
                {
                    bi.Write(mas[i]);
                }
                bi.Close();
                g.Close();
            }
            if (Reason == "Change")
            {
                int.TryParse(Number.Text, out int n);
                FileStream f = new FileStream(textBox1.Text, FileMode.Open);
                BinaryReader b = new BinaryReader(f);
                List<string> mas = new List<string>();
                try
                {
                    while (true)
                    {
                        mas.Add(b.ReadString());
                    }
                }
                catch (EndOfStreamException)
                {
                }
                b.Close();
                f.Close();
                if (listBox1.SelectedItem.ToString() == "Автоматически")
                {
                    FileStream fq = new FileStream(textBox1.Text, FileMode.Create);
                    BinaryWriter bq = new BinaryWriter(fq);
                    Gener gen = new Gener();
                    for (int i = 0; i < (n - 1) * 6; i++)
                    {
                        bq.Write(mas[i]);
                    }
                    bq.Write(gen.Name);
                    bq.Write(gen.Adress);
                    bq.Write(gen.Number.ToString());
                    bq.Write(gen.Edu);
                    bq.Write(gen.Ord.ToString());
                    bq.Write("\n");
                    for (int i = (n * 6); i < mas.Count; i++)
                    {
                        bq.Write(mas[i]);
                    }
                    bq.Close();
                    fq.Close();

                }
                else
                {
                    FileStream fq = new FileStream(textBox1.Text, FileMode.Create);
                    BinaryWriter bq = new BinaryWriter(fq);
                    Hand han = new Hand();
                    han.ShowDialog();
                    if (han.DialogResult == DialogResult.OK)
                    {
                        for (int i = 0; i < (n - 1) * 6; i++)
                        {
                            bq.Write(mas[i]);
                        }
                        bq.Write(han.Nameq.Text);
                        bq.Write(han.Adress.Text);
                        bq.Write(han.Phone.Text);
                        bq.Write(han.Edu.Text);
                        bq.Write(han.Ord.Text);
                        bq.Write("\n");
                        for (int i = (n * 6); i < mas.Count; i++)
                        {
                            bq.Write(mas[i]);
                        }
                    }
                    bq.Close();
                    fq.Close();
                }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.Reason == "Change")
            {
                if (Number.Text.Length != 0)
                {
                    if (int.TryParse(Number.Text, out int n) == true)
                    {
                        if (n > 0)
                        {
                            if (listBox1.GetSelected(0) == true || listBox1.GetSelected(1) == true)
                            {
                                FileStream f = new FileStream(textBox1.Text, FileMode.Open);
                                BinaryReader b = new BinaryReader(f);
                                List<string> mas = new List<string>();
                                try
                                {
                                    while (true)
                                    {
                                        mas.Add(b.ReadString());
                                    }
                                }
                                catch (EndOfStreamException)
                                {
                                }
                                b.Close();
                                f.Close();
                                if ((n) <= (mas.Count / 6))
                                {
                                    Ready.Enabled = true;
                                    Ready.Visible = true;
                                }
                                else Ready.Enabled = false;
                            }
                            else Ready.Enabled = false;
                        }
                        else Ready.Enabled = false;
                    }
                    else Ready.Enabled = false;
                }
                else Ready.Enabled = false;
            }
        }
    }
}
