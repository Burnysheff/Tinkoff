﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppKR
{
    public partial class Hand : Form
    {
        public Hand()
        {
            InitializeComponent();
        }

        private void Name_TextChanged(object sender, EventArgs e)
        {
            if (Nameq.Text.Length != 0 && Adress.Text.Length != 0 && Phone.Text.Length != 0 && Edu.Text.Length != 0 && Ord.Text.Length != 0)
            {
                if (int.TryParse(Phone.Text, out int a) == true && int.TryParse(Ord.Text, out int b) == true)
                {
                    if (a > 0 && b > 0)
                    {
                        OK.Enabled = true;
                    }
                    else OK.Enabled = false;
                }
                else OK.Enabled = false;
            }
            else OK.Enabled = false;
        }

        private void Err_Click(object sender, EventArgs e)
        {

        }

        private void Hand_Load(object sender, EventArgs e)
        {

        }

        private void Adress_TextChanged(object sender, EventArgs e)
        {
            if (Nameq.Text.Length != 0 && Adress.Text.Length != 0 && Phone.Text.Length != 0 && Edu.Text.Length != 0 && Ord.Text.Length != 0)
            {
                if (int.TryParse(Phone.Text, out int a) == true && int.TryParse(Ord.Text, out int b) == true)
                {
                    if (a > 0 && b > 0)
                    {
                        OK.Enabled = true;
                    }
                    else OK.Enabled = false;
                }
                else OK.Enabled = false;
            }
            else OK.Enabled = false;
        }

        private void Phone_TextChanged(object sender, EventArgs e)
        {
            if (Nameq.Text.Length != 0 && Adress.Text.Length != 0 && Phone.Text.Length != 0 && Edu.Text.Length != 0 && Ord.Text.Length != 0)
            {
                if (int.TryParse(Phone.Text, out int a) == true && int.TryParse(Ord.Text, out int b) == true)
                {
                    if (a > 0 && b > 0)
                    {
                        OK.Enabled = true;
                    }
                    else OK.Enabled = false;
                }
                else OK.Enabled = false;
            }
            else OK.Enabled = false;
        }

        private void Edu_TextChanged(object sender, EventArgs e)
        {
            if (Nameq.Text.Length != 0 && Adress.Text.Length != 0 && Phone.Text.Length != 0 && Edu.Text.Length != 0 && Ord.Text.Length != 0)
            {
                if (int.TryParse(Phone.Text, out int a) == true && int.TryParse(Ord.Text, out int b) == true)
                {
                    if (a > 0 && b > 0)
                    {
                        OK.Enabled = true;
                    }
                    else OK.Enabled = false;
                }
                else OK.Enabled = false;
            }
            else OK.Enabled = false;
        }

        private void Ord_TextChanged(object sender, EventArgs e)
        {
            if (Nameq.Text.Length != 0 && Adress.Text.Length != 0 && Phone.Text.Length != 0 && Edu.Text.Length != 0 && Ord.Text.Length != 0)
            {
                if (int.TryParse(Phone.Text, out int a) == true && int.TryParse(Ord.Text, out int b) == true)
                {
                    if (a > 0 && b > 0)
                    {
                        OK.Enabled = true;
                    }
                    else OK.Enabled = false;
                }
                else OK.Enabled = false;
            }
            else OK.Enabled = false;
        }
    }
}
