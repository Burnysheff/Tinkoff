﻿
namespace WindowsFormsAppKR
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.Create = new System.Windows.Forms.Button();
            this.Watch = new System.Windows.Forms.Button();
            this.WatchAll = new System.Windows.Forms.Button();
            this.Add = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            this.Change = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.All = new System.Windows.Forms.Button();
            this.Sotr = new System.Windows.Forms.Button();
            this.Educat = new System.Windows.Forms.Button();
            this.linq = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Create
            // 
            this.Create.Location = new System.Drawing.Point(58, 45);
            this.Create.Name = "Create";
            this.Create.Size = new System.Drawing.Size(92, 37);
            this.Create.TabIndex = 0;
            this.Create.Text = "Создать новый файл\r\n";
            this.Create.UseVisualStyleBackColor = true;
            this.Create.Click += new System.EventHandler(this.Create_Click);
            // 
            // Watch
            // 
            this.Watch.Enabled = false;
            this.Watch.Location = new System.Drawing.Point(254, 45);
            this.Watch.Name = "Watch";
            this.Watch.Size = new System.Drawing.Size(92, 37);
            this.Watch.TabIndex = 1;
            this.Watch.Text = "Просмотреть файл";
            this.Watch.UseVisualStyleBackColor = true;
            this.Watch.Click += new System.EventHandler(this.Watch_Click);
            // 
            // WatchAll
            // 
            this.WatchAll.Enabled = false;
            this.WatchAll.Location = new System.Drawing.Point(461, 45);
            this.WatchAll.Name = "WatchAll";
            this.WatchAll.Size = new System.Drawing.Size(92, 37);
            this.WatchAll.TabIndex = 2;
            this.WatchAll.Text = "Просмотр всех файлов";
            this.WatchAll.UseVisualStyleBackColor = true;
            this.WatchAll.Click += new System.EventHandler(this.WatchAll_Click);
            // 
            // Add
            // 
            this.Add.Enabled = false;
            this.Add.Location = new System.Drawing.Point(58, 166);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(92, 37);
            this.Add.TabIndex = 3;
            this.Add.Text = "Добавить элемент";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.button1_Click);
            // 
            // Delete
            // 
            this.Delete.Enabled = false;
            this.Delete.Location = new System.Drawing.Point(254, 166);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(92, 37);
            this.Delete.TabIndex = 4;
            this.Delete.Text = "Удалить элемент";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Change
            // 
            this.Change.Enabled = false;
            this.Change.Location = new System.Drawing.Point(461, 166);
            this.Change.Name = "Change";
            this.Change.Size = new System.Drawing.Size(92, 37);
            this.Change.TabIndex = 5;
            this.Change.Text = "Поменять элемент";
            this.Change.UseVisualStyleBackColor = true;
            this.Change.Click += new System.EventHandler(this.Change_Click);
            // 
            // listBox1
            // 
            this.listBox1.DisplayMember = "GetIt";
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Items.AddRange(new object[] {
            "Автоматически",
            "Вручную"});
            this.listBox1.Location = new System.Drawing.Point(58, 108);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(108, 17);
            this.listBox1.TabIndex = 6;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // All
            // 
            this.All.Location = new System.Drawing.Point(-133, 278);
            this.All.Name = "All";
            this.All.Size = new System.Drawing.Size(92, 50);
            this.All.TabIndex = 7;
            this.All.Text = "Список сотрудников отделения";
            this.All.UseVisualStyleBackColor = true;
            // 
            // Sotr
            // 
            this.Sotr.Enabled = false;
            this.Sotr.Location = new System.Drawing.Point(58, 263);
            this.Sotr.Name = "Sotr";
            this.Sotr.Size = new System.Drawing.Size(92, 49);
            this.Sotr.TabIndex = 8;
            this.Sotr.Text = "Список сотрудников отделения";
            this.Sotr.UseVisualStyleBackColor = true;
            this.Sotr.Click += new System.EventHandler(this.Sotr_Click);
            // 
            // Educat
            // 
            this.Educat.Enabled = false;
            this.Educat.Location = new System.Drawing.Point(237, 263);
            this.Educat.Name = "Educat";
            this.Educat.Size = new System.Drawing.Size(134, 80);
            this.Educat.TabIndex = 9;
            this.Educat.Text = "Количество сотрудников с высшим образованием в подразделении";
            this.Educat.UseVisualStyleBackColor = true;
            this.Educat.Click += new System.EventHandler(this.Educat_Click);
            // 
            // linq
            // 
            this.linq.Enabled = false;
            this.linq.Location = new System.Drawing.Point(461, 263);
            this.linq.Name = "linq";
            this.linq.Size = new System.Drawing.Size(92, 49);
            this.linq.TabIndex = 10;
            this.linq.Text = "Количество женщин в файле\r\n";
            this.linq.UseVisualStyleBackColor = true;
            this.linq.Click += new System.EventHandler(this.linq_Click);
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(449, 331);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 42);
            this.button1.TabIndex = 11;
            this.button1.Text = "Показать текстовый файл";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(612, 401);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.linq);
            this.Controls.Add(this.Educat);
            this.Controls.Add(this.Sotr);
            this.Controls.Add(this.All);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.Change);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.WatchAll);
            this.Controls.Add(this.Watch);
            this.Controls.Add(this.Create);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Create;
        private System.Windows.Forms.Button Watch;
        private System.Windows.Forms.Button WatchAll;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Button Change;
        public System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button All;
        private System.Windows.Forms.Button Sotr;
        private System.Windows.Forms.Button Educat;
        private System.Windows.Forms.Button linq;
        private System.Windows.Forms.Button button1;
    }
}

