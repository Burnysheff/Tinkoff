﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppKR
{
    public class Gener
    {
        static Random rnd = new Random();
        public string Name;
        public string Adress;
        public int Number;
        public string Edu;
        public int Ord;
        public Gener()
        {
            string[] masname = { "Krasnova", "Belova", "Chernova", "Ivanova", "Petrova", "Krasnov", "Belov", "Chernov", "Ivanov", "Petrov" };
            string[] masadress = { "Perm", "Moscow", "Saint-Petersberg", "Ufa", "Ekaterinburg", "Tomsk", "Smolensk", "Kursk" };
            string[] masedu = { "High", "Middle", "Middle-Special", "PHd", "4-classes" };
            Name = masname[rnd.Next(masname.Length)];
            Adress = masadress[rnd.Next(masadress.Length)];
            Number = rnd.Next(700000, 800000);
            Edu = masedu[rnd.Next(masedu.Length)];
            Ord = rnd.Next(10);
        }
    }
}
