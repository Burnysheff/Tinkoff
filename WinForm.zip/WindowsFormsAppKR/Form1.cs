﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsAppKR
{
    public partial class Form1 : Form
    {
        public static string zaq;
        static public List<string> names = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Name nam = new Name();
            nam.Reason = "Add";
            nam.label3.Visible = true;
            nam.ShowDialog();
        }

        private void Create_Click(object sender, EventArgs e)
        {
            Name nam = new Name();
            nam.label2.Visible = true;
            nam.Number.Visible = true;
            nam.textBox1.Visible = true;
            nam.Reason = "Create";
            listBox1.Select();
            nam.Form = listBox1.SelectedItem.ToString();
            nam.ShowDialog();
            Watch.Enabled = true;
            WatchAll.Enabled = true;
            Add.Enabled = true;
            Delete.Enabled = true;
            Change.Enabled = true;
            Sotr.Enabled = true;
            Educat.Enabled = true;
            linq.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            {
                Create.Enabled = false;
            }
            else Create.Enabled = true;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Create.Enabled = true;
        }

        private void Watch_Click(object sender, EventArgs e)
        {
            Name nam = new Name();
            nam.Reason = "Watch";
            nam.label3.Visible = true;
            nam.ShowDialog();
        }

        private void WatchAll_Click(object sender, EventArgs e)
        {
            Name nam = new Name();
            nam.Reason = "WatchAll";
            nam.label3.Visible = true;
            nam.ShowDialog();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            Name nam = new Name();
            nam.Reason = "Delete";
            nam.label3.Visible = true;
            nam.ShowDialog();
        }

        private void Change_Click(object sender, EventArgs e)
        {
            Name nam = new Name();
            nam.Reason = "Change";
            nam.label3.Visible = true;
            nam.ShowDialog();
        }

        private void Sotr_Click(object sender, EventArgs e)
        {
            Name nam = new Name();
            nam.Reason = "All";
            nam.label1.Text = "Укажите номер отделения:";
            nam.ShowDialog();
        }

        private void Educat_Click(object sender, EventArgs e)
        {
            Name nam = new Name();
            nam.Reason = "Edu";
            nam.label1.Text = "Укажите номер отделения:";
            nam.ShowDialog();
        }

        private void linq_Click(object sender, EventArgs e)
        {
            Name nam = new Name();
            nam.Reason = "linq";
            //nam.label1.Text = "Введие название результирующего";
            nam.ShowDialog();
            if (nam.DialogResult == DialogResult.OK)
            {
                button1.Enabled = true;
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            StreamReader str = new StreamReader(zaq);
            string res = str.ReadToEnd();
            Answer ans = new Answer();
            ans.label1.Text = res;
            ans.ShowDialog();
        }
    }
}
